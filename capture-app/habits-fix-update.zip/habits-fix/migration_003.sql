-- Migration 003: Link tasks to habits they'll log on completion
-- Run in Supabase SQL Editor

alter table items add column if not exists pending_habit_id uuid references habits(id) on delete set null;
