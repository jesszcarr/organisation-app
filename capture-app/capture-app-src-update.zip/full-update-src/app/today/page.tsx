'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Item, Category, Project, Habit, HabitLog } from '@/types/database'
import { createClient } from '@/lib/supabase/client'
import { BottomNav } from '@/components/app/BottomNav'
import { ChevronLeft, ChevronRight } from 'lucide-react'

function formatDate(date: Date) {
  return date.toISOString().split('T')[0]
}

function getWeekDates(referenceDate: Date): Date[] {
  const day = referenceDate.getDay()
  const monday = new Date(referenceDate)
  monday.setDate(referenceDate.getDate() - ((day + 6) % 7))
  const dates: Date[] = []
  for (let i = 0; i < 7; i++) {
    const d = new Date(monday)
    d.setDate(monday.getDate() + i)
    dates.push(d)
  }
  return dates
}

const DAY_NAMES = ['M', 'T', 'W', 'T', 'F', 'S', 'S']

const TYPE_COLORS: Record<string, string> = {
  achievement: 'bg-emerald-200 dark:bg-emerald-800',
  project_update: 'bg-blue-200 dark:bg-blue-800',
  reflection: 'bg-amber-200 dark:bg-amber-800',
  habit_entry: 'bg-purple-200 dark:bg-purple-800',
  task: 'bg-gray-200 dark:bg-gray-700',
  link: 'bg-sky-200 dark:bg-sky-800',
}

export default function TodayPage() {
  const router = useRouter()
  const [currentDate, setCurrentDate] = useState(new Date())
  const [items, setItems] = useState<(Item & { category?: Category; project?: Project })[]>([])
  const [habits, setHabits] = useState<Habit[]>([])
  const [habitLogs, setHabitLogs] = useState<HabitLog[]>([])
  const [loading, setLoading] = useState(true)

  const dateStr = formatDate(currentDate)
  const weekDates = getWeekDates(currentDate)
  const weekFrom = formatDate(weekDates[0])
  const weekTo = formatDate(weekDates[6])

  const isToday = formatDate(new Date()) === dateStr

  const displayDate = new Intl.DateTimeFormat('en', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
  }).format(currentDate)

  useEffect(() => {
    const supabase = createClient()
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (!user) { router.push('/login'); return }
      loadData()
    })
  }, [router, dateStr, weekFrom, weekTo])

  async function loadData() {
    setLoading(true)
    const [itemsRes, habitsRes, logsRes] = await Promise.all([
      fetch(`/api/items?date=${dateStr}`),
      fetch('/api/habits'),
      fetch(`/api/habit-logs?from=${weekFrom}&to=${weekTo}`),
    ])
    if (itemsRes.ok) setItems(await itemsRes.json())
    if (habitsRes.ok) setHabits(await habitsRes.json())
    if (logsRes.ok) setHabitLogs(await logsRes.json())
    setLoading(false)
  }

  function goDay(offset: number) {
    const next = new Date(currentDate)
    next.setDate(next.getDate() + offset)
    if (next <= new Date()) setCurrentDate(next)
  }

  // Build habit log lookup: habit_id -> { date -> value }
  const logLookup: Record<string, Record<string, number>> = {}
  for (const log of habitLogs) {
    if (!logLookup[log.habit_id]) logLookup[log.habit_id] = {}
    logLookup[log.habit_id][log.log_date] = log.value
  }

  // Get today's value for display
  function todayValue(habit: Habit): string {
    const val = logLookup[habit.id]?.[dateStr]
    if (val === undefined) return '—'
    if (habit.track_type === 'binary') return '✓'
    return `${val}${habit.unit ? habit.unit : ''}`
  }

  const formattedTime = (dateStr: string) =>
    new Intl.DateTimeFormat('en', {
      hour: 'numeric',
      minute: '2-digit',
    }).format(new Date(dateStr))

  // Filter out pure tasks from the "what you did" — show achievements, reflections, project updates, habit entries
  const meaningfulItems = items.filter(i => i.type !== 'task' && i.type !== 'link')
  const allItems = items

  return (
    <div className="flex flex-col h-screen bg-background">
      {/* Date nav */}
      <header className="flex items-center justify-between px-4 h-12 border-b shrink-0">
        <button onClick={() => goDay(-1)} className="p-2 text-muted-foreground hover:text-foreground">
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="text-center">
          <h1 className="font-semibold text-sm">{displayDate}</h1>
          {isToday && <span className="text-xs text-muted-foreground">Today</span>}
        </div>
        <button
          onClick={() => goDay(1)}
          disabled={isToday}
          className="p-2 text-muted-foreground hover:text-foreground disabled:opacity-30"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </header>

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-2xl mx-auto">

          {/* What you did today - ABOVE habits as requested */}
          <section className="px-4 py-4 border-b">
            <h2 className="text-xs font-medium uppercase tracking-wide text-muted-foreground mb-3">
              What you did {isToday ? 'today' : ''}
            </h2>

            {loading ? (
              <p className="text-sm text-muted-foreground text-center py-4">Loading…</p>
            ) : meaningfulItems.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                {isToday ? 'Nothing logged yet — type in Capture to add' : 'Nothing logged this day'}
              </p>
            ) : (
              <div className="space-y-3">
                {[...meaningfulItems].reverse().map((item) => (
                  <div key={item.id} className="flex gap-3 items-start">
                    <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${TYPE_COLORS[item.type] || TYPE_COLORS.task}`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm leading-relaxed">{item.content}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-xs text-muted-foreground">{formattedTime(item.created_at)}</span>
                        {item.project && (
                          <span className="text-xs text-emerald-600 dark:text-emerald-400">
                            {item.project.emoji} {item.project.name}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Also show tasks/links if any, collapsed */}
            {allItems.filter(i => i.type === 'task' || i.type === 'link').length > 0 && (
              <details className="mt-4">
                <summary className="text-xs text-muted-foreground cursor-pointer hover:text-foreground">
                  + {allItems.filter(i => i.type === 'task' || i.type === 'link').length} tasks &amp; links
                </summary>
                <div className="space-y-2 mt-2">
                  {allItems.filter(i => i.type === 'task' || i.type === 'link').reverse().map((item) => (
                    <div key={item.id} className="flex gap-3 items-start">
                      <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${TYPE_COLORS[item.type]}`} />
                      <div>
                        <p className="text-sm text-muted-foreground">{item.content}</p>
                        <span className="text-xs text-muted-foreground">{formattedTime(item.created_at)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </details>
            )}
          </section>

          {/* Habits this week */}
          <section className="px-4 py-4">
            <h2 className="text-xs font-medium uppercase tracking-wide text-muted-foreground mb-3">Habits this week</h2>

            {/* Day headers */}
            <div className="flex items-center mb-1">
              <div className="flex-1" />
              <div className="flex gap-1">
                {weekDates.map((d, i) => (
                  <div
                    key={i}
                    className={`w-7 text-center text-[10px] ${
                      formatDate(d) === dateStr
                        ? 'text-foreground font-medium'
                        : 'text-muted-foreground'
                    }`}
                  >
                    {DAY_NAMES[i]}
                  </div>
                ))}
              </div>
              <div className="w-10" />
            </div>

            {/* Habit rows */}
            {habits.filter(h => h.active).map((habit) => (
              <div key={habit.id} className="flex items-center py-1.5">
                <div className="flex-1 text-sm truncate">
                  {habit.emoji} {habit.name}
                </div>
                <div className="flex gap-1">
                  {weekDates.map((d, i) => {
                    const ds = formatDate(d)
                    const val = logLookup[habit.id]?.[ds]
                    const isDone = val !== undefined
                    const isCurrent = ds === dateStr
                    return (
                      <div
                        key={i}
                        className={`w-7 h-7 rounded-sm flex items-center justify-center text-[10px] ${
                          isDone
                            ? isCurrent
                              ? 'bg-emerald-500 text-white'
                              : 'bg-emerald-100 dark:bg-emerald-900 text-emerald-700 dark:text-emerald-300'
                            : isCurrent
                            ? 'border-2 border-muted-foreground/30 bg-background'
                            : 'bg-muted'
                        }`}
                      >
                        {isDone && habit.track_type === 'binary' ? '✓' : isDone ? Math.round(val) : ''}
                      </div>
                    )
                  })}
                </div>
                <div className="w-10 text-right text-xs text-muted-foreground">
                  {todayValue(habit)}
                </div>
              </div>
            ))}

            {habits.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">No habits set up yet</p>
            )}
          </section>
        </div>
      </div>

      <BottomNav />
    </div>
  )
}
