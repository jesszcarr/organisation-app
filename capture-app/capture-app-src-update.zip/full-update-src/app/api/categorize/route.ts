import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'
import { createClient } from '@/lib/supabase/server'
import { buildRoutingPrompt } from '@/lib/categorize'

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
})

export async function POST(request: NextRequest) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { message } = await request.json() as { message: string }

  if (!message) {
    return NextResponse.json({ error: 'Missing message' }, { status: 400 })
  }

  // Fetch categories, projects, habits for routing context
  const [catsRes, projRes, habRes] = await Promise.all([
    supabase.from('categories').select('*').eq('user_id', user.id).order('sort_order'),
    supabase.from('projects').select('*').eq('user_id', user.id).eq('status', 'active'),
    supabase.from('habits').select('*').eq('user_id', user.id).eq('active', true),
  ])

  const categories = catsRes.data ?? []
  const projects = projRes.data ?? []
  const habits = habRes.data ?? []

  const prompt = buildRoutingPrompt(message, categories, projects, habits)

  try {
    const response = await anthropic.messages.create({
      model: 'claude-haiku-4-5-20251001',
      max_tokens: 300,
      messages: [{ role: 'user', content: prompt }],
    })

    const raw = (response.content[0] as { type: string; text: string }).text.trim()

    // Strip markdown code fences if present
    const cleaned = raw.replace(/^```json?\s*/, '').replace(/\s*```$/, '')

    const parsed = JSON.parse(cleaned)

    return NextResponse.json({
      type: parsed.type || 'task',
      category_id: parsed.category_id || null,
      project_id: parsed.project_id || null,
      habits: parsed.habits || [],
      method: 'ai',
    })
  } catch (e) {
    console.error('Routing failed:', e)
    // Fallback: save as task with no category
    return NextResponse.json({
      type: 'task',
      category_id: null,
      project_id: null,
      habits: [],
      method: 'ai_fallback',
    })
  }
}
