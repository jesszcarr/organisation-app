import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(request: NextRequest) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { searchParams } = new URL(request.url)
  const categoryId = searchParams.get('category_id')
  const projectId = searchParams.get('project_id')
  const type = searchParams.get('type')
  const search = searchParams.get('search')
  const date = searchParams.get('date') // YYYY-MM-DD for "today" view

  // Full-text search path
  if (search) {
    const { data, error } = await supabase
      .rpc('search_items', { query: search, p_user_id: user.id })
    if (error) return NextResponse.json({ error: error.message }, { status: 500 })

    // Fetch categories and projects for the returned items
    const itemIds = (data ?? []).map((i: { id: string }) => i.id)
    if (itemIds.length === 0) return NextResponse.json([])

    const { data: enriched } = await supabase
      .from('items')
      .select('*, category:categories(*), project:projects(*)')
      .in('id', itemIds)
      .order('created_at', { ascending: false })

    return NextResponse.json(enriched ?? [])
  }

  let query = supabase
    .from('items')
    .select('*, category:categories(*), project:projects(*)')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })
    .limit(200)

  if (categoryId) query = query.eq('category_id', categoryId)
  if (projectId) query = query.eq('project_id', projectId)
  if (type) query = query.eq('type', type)
  if (date) {
    query = query
      .gte('created_at', `${date}T00:00:00`)
      .lt('created_at', `${date}T23:59:59`)
  }

  const { data, error } = await query
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data)
}

export async function POST(request: NextRequest) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await request.json()
  const { content, type, category_id, project_id, categorized_by, habits } = body

  // Insert the item
  const { data: item, error } = await supabase
    .from('items')
    .insert({
      content,
      type: type || 'task',
      category_id: category_id || null,
      project_id: project_id || null,
      categorized_by: categorized_by || 'manual',
      user_id: user.id,
    })
    .select('*, category:categories(*), project:projects(*)')
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  // Create habit logs if any were extracted
  if (habits && habits.length > 0 && item) {
    const today = new Date().toISOString().split('T')[0]
    for (const h of habits) {
      // Upsert: update if already logged today, insert otherwise
      await supabase
        .from('habit_logs')
        .upsert(
          {
            habit_id: h.habit_id,
            item_id: item.id,
            log_date: today,
            value: h.value || 1,
            note: h.note || null,
          },
          { onConflict: 'habit_id,log_date' }
        )
    }
  }

  return NextResponse.json(item, { status: 201 })
}
