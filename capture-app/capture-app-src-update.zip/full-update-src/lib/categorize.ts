import { KeywordRule, Category, Project, Habit } from '@/types/database'

/**
 * Try to match a message against keyword rules (client-safe, no API needed).
 * Returns the matching category_id or null.
 */
export function matchKeywordRules(
  message: string,
  rules: KeywordRule[]
): string | null {
  const lower = message.toLowerCase()
  for (const rule of rules) {
    if (lower.includes(rule.keyword.toLowerCase())) {
      return rule.category_id
    }
  }
  return null
}

/**
 * Build the prompt for AI routing — returns structured JSON with
 * type, category, project, and habit extractions.
 */
export function buildRoutingPrompt(
  message: string,
  categories: Category[],
  projects: Project[],
  habits: Habit[]
): string {
  const topLevel = categories.filter((c) => !c.parent_id)
  const categoryList = topLevel.map((c) => `- ${c.name} (id: ${c.id})`).join('\n')
  const projectList = projects.map((p) => `- ${p.name} (id: ${p.id})`).join('\n')
  const habitList = habits.map((h) => `- ${h.name} (id: ${h.id}, type: ${h.track_type}${h.unit ? `, unit: ${h.unit}` : ''})`).join('\n')

  return `You are a personal note router. Analyse the following message and return a JSON object with these fields:

1. "type": one of: task, reflection, achievement, project_update, link, habit_entry
   - task: something to do (buy X, todo Y, remember to Z)
   - reflection: thoughts, feelings, observations about life
   - achievement: something accomplished today
   - project_update: progress on a research project
   - link: a URL or recommendation to save
   - habit_entry: mentions doing a tracked activity (running, gym, piano, project work)
   Note: a message can be BOTH a project_update AND contain habit data. In that case, use "project_update" as the type.

2. "category_id": the best matching category ID, or null if none fit
Categories:
${categoryList}

3. "project_id": the best matching project ID, or null if not project-related
Projects:
${projectList}

4. "habits": array of habit extractions, or empty array. Each entry: {"habit_id": "...", "value": number, "note": "optional context"}
   - For binary habits, value = 1
   - For numeric habits, extract the number (e.g. "ran 5k" → value: 5, "piano 30 mins" → value: 30)
Tracked habits:
${habitList}

Reply with ONLY valid JSON, no explanation.

Message: "${message}"

JSON:`
}

/**
 * Legacy prompt for simple categorization (fallback).
 */
export function buildCategorizationPrompt(
  message: string,
  categories: Category[]
): string {
  const topLevel = categories.filter((c) => !c.parent_id)
  const categoryList = topLevel
    .map((c) => `- ${c.name}`)
    .join('\n')

  return `You are a personal note categorizer. Classify the following note into exactly one of these categories. Reply with only the category name, nothing else.

Categories:
${categoryList}

Note: "${message}"

Category:`
}
