import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function GET(request: NextRequest) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorised' }, { status: 401 })

  const { searchParams } = new URL(request.url)
  const categoryId = searchParams.get('category_id')
  const projectId = searchParams.get('project_id')
  const type = searchParams.get('type')
  const search = searchParams.get('search')
  const date = searchParams.get('date')
  const tag = searchParams.get('tag')
  const completedDate = searchParams.get('completed_date') // for "done today"

  // Full-text search
  if (search) {
    const { data } = await supabase.rpc('search_items', { query: search, p_user_id: user.id })
    const ids = (data ?? []).map((i: { id: string }) => i.id)
    if (ids.length === 0) return NextResponse.json([])
    const { data: enriched } = await supabase
      .from('items').select('*, category:categories(*), project:projects(*)').in('id', ids)
      .order('created_at', { ascending: false })
    return NextResponse.json(enriched ?? [])
  }

  // Tag filter — need to go through item_tags
  if (tag) {
    const { data: tagRow } = await supabase
      .from('tags').select('id').eq('user_id', user.id).eq('name', tag.toLowerCase()).single()
    if (!tagRow) return NextResponse.json([])
    const { data: itemTags } = await supabase
      .from('item_tags').select('item_id').eq('tag_id', tagRow.id)
    const ids = (itemTags ?? []).map(it => it.item_id)
    if (ids.length === 0) return NextResponse.json([])
    const { data } = await supabase
      .from('items').select('*, category:categories(*), project:projects(*)').in('id', ids)
      .eq('user_id', user.id).order('created_at', { ascending: false }).limit(200)
    return NextResponse.json(data ?? [])
  }

  let query = supabase
    .from('items').select('*, category:categories(*), project:projects(*)')
    .eq('user_id', user.id).order('created_at', { ascending: false }).limit(200)

  if (categoryId) query = query.eq('category_id', categoryId)
  if (projectId) query = query.eq('project_id', projectId)
  if (type) query = query.eq('type', type)
  if (date) {
    query = query.gte('created_at', `${date}T00:00:00`).lt('created_at', `${date}T23:59:59`)
  }
  if (completedDate) {
    query = query.not('completed_at', 'is', null)
      .gte('completed_at', `${completedDate}T00:00:00`)
      .lt('completed_at', `${completedDate}T23:59:59`)
  }

  const { data, error } = await query
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data)
}

export async function POST(request: NextRequest) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorised' }, { status: 401 })

  const body = await request.json()
  const { content, type, category_id, project_id, categorized_by, habits, tags } = body

  const { data: item, error } = await supabase
    .from('items')
    .insert({
      content,
      type: type || 'task',
      category_id: category_id || null,
      project_id: project_id || null,
      categorized_by: categorized_by || 'manual',
      user_id: user.id,
    })
    .select('*, category:categories(*), project:projects(*)')
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  // Create habit logs
  if (habits?.length > 0 && item) {
    const today = new Date().toISOString().split('T')[0]
    for (const h of habits) {
      await supabase.from('habit_logs').upsert(
        { habit_id: h.habit_id, item_id: item.id, log_date: today, value: h.value || 1, note: h.note || null },
        { onConflict: 'habit_id,log_date' }
      )
    }
  }

  // Create/link tags
  if (tags?.length > 0 && item) {
    for (const tagName of tags) {
      const name = tagName.toLowerCase().trim()
      if (!name) continue
      // Upsert tag
      let { data: tagRow } = await supabase
        .from('tags').select('id').eq('user_id', user.id).eq('name', name).single()
      if (!tagRow) {
        const { data: newTag } = await supabase
          .from('tags').insert({ user_id: user.id, name }).select('id').single()
        tagRow = newTag
      }
      if (tagRow) {
        await supabase.from('item_tags').upsert(
          { item_id: item.id, tag_id: tagRow.id },
          { onConflict: 'item_id,tag_id' }
        )
      }
    }
  }

  return NextResponse.json(item, { status: 201 })
}
