import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'
import { createClient } from '@/lib/supabase/server'
import { buildRoutingPrompt, matchProjectAliases } from '@/lib/categorize'

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY! })

export async function POST(request: NextRequest) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorised' }, { status: 401 })

  const { message } = await request.json() as { message: string }
  if (!message) return NextResponse.json({ error: 'Missing message' }, { status: 400 })

  const [catsRes, projRes, habRes] = await Promise.all([
    supabase.from('categories').select('*').eq('user_id', user.id).order('sort_order'),
    supabase.from('projects').select('*').eq('user_id', user.id).eq('status', 'active'),
    supabase.from('habits').select('*').eq('user_id', user.id).eq('active', true),
  ])

  const categories = catsRes.data ?? []
  const projects = projRes.data ?? []
  const habits = habRes.data ?? []
  const aliasMatch = matchProjectAliases(message, projects)

  try {
    const prompt = buildRoutingPrompt(message, categories, projects, habits)
    const response = await anthropic.messages.create({
      model: 'claude-haiku-4-5-20251001',
      max_tokens: 400,
      messages: [{ role: 'user', content: prompt }],
    })
    const raw = (response.content[0] as { type: string; text: string }).text.trim()
    const cleaned = raw.replace(/^```json?\s*/, '').replace(/\s*```$/, '')
    const parsed = JSON.parse(cleaned)

    const projectId = parsed.project_id || aliasMatch || null
    const type = projectId && parsed.type === 'task' ? 'project_update' : (parsed.type || 'task')

    return NextResponse.json({
      type,
      category_id: parsed.category_id || null,
      project_id: projectId,
      habits: parsed.habits || [],
      tags: parsed.tags || [],
      method: 'ai',
    })
  } catch (e) {
    console.error('Routing failed:', e)
    return NextResponse.json({
      type: aliasMatch ? 'project_update' : 'task',
      category_id: null,
      project_id: aliasMatch,
      habits: [],
      tags: [],
      method: 'ai_fallback',
    })
  }
}
