import { KeywordRule, Category, Project, Habit } from '@/types/database'

export function matchKeywordRules(message: string, rules: KeywordRule[]): string | null {
  const lower = message.toLowerCase()
  for (const rule of rules) {
    if (lower.includes(rule.keyword.toLowerCase())) return rule.category_id
  }
  return null
}

export function matchProjectAliases(message: string, projects: Project[]): string | null {
  const lower = message.toLowerCase()
  const words = lower.split(/\s+/)

  for (const project of projects) {
    if (lower.includes(project.name.toLowerCase())) return project.id
    if (!project.aliases) continue
    const aliases = project.aliases.split(',').map((a) => a.trim().toLowerCase()).filter(Boolean)
    for (const alias of aliases) {
      if (alias.length <= 3) {
        if (words.includes(alias)) return project.id
      } else {
        if (lower.includes(alias)) return project.id
      }
    }
  }
  return null
}

export function buildRoutingPrompt(
  message: string,
  categories: Category[],
  projects: Project[],
  habits: Habit[]
): string {
  const topLevel = categories.filter((c) => !c.parent_id)
  const categoryList = topLevel.map((c) => `- ${c.name} (id: ${c.id})`).join('\n')
  const projectList = projects.map((p) => {
    const parts = [`- ${p.name} (id: ${p.id})`]
    if (p.description) parts.push(`  Description: ${p.description}`)
    if (p.aliases) parts.push(`  Aliases/collaborators: ${p.aliases}`)
    return parts.join('\n')
  }).join('\n')
  const habitList = habits.map((h) =>
    `- ${h.name} (id: ${h.id}, type: ${h.track_type}${h.unit ? `, unit: ${h.unit}` : ''})`
  ).join('\n')

  return `You are a personal note router. Analyse the following message and return a JSON object:

1. "type": one of: task, reflection, achievement, project_update, link, habit_entry
   - task: something to do (buy X, todo Y, need to send X)
   - reflection: thoughts, feelings, observations
   - achievement: something accomplished
   - project_update: progress on or discussion about a research project
   - link: a URL or recommendation to save
   - habit_entry: mentions doing a tracked activity
   A message can be BOTH a project_update AND contain habit data — use "project_update".

2. "category_id": best matching category ID, or null
Categories:
${categoryList}

3. "project_id": best matching project ID, or null.
   Match on names, descriptions, aliases, AND collaborator names.
Projects:
${projectList}

4. "habits": array of extractions, or []. Each: {"habit_id": "...", "value": number, "note": "optional"}
Habits:
${habitList}

5. "tags": array of lowercase string tags. Extract people mentioned by name and meaningful topics/themes. Only genuinely useful tags.

Reply with ONLY valid JSON.

Message: "${message}"

JSON:`
}

export function buildCategorizationPrompt(message: string, categories: Category[]): string {
  const topLevel = categories.filter((c) => !c.parent_id)
  const categoryList = topLevel.map((c) => `- ${c.name}`).join('\n')
  return `You are a personal note categoriser. Classify into exactly one category. Reply with only the category name.

Categories:
${categoryList}

Note: "${message}"

Category:`
}
