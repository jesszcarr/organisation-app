'use client'

import { useState } from 'react'
import { Item, Category, Project } from '@/types/database'
import { Badge } from '@/components/ui/badge'
import { Trash2 } from 'lucide-react'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

interface MessageBubbleProps {
  item: Item & { category?: Category; project?: Project }
  categories?: Category[]
  onReassign?: (itemId: string, categoryId: string) => void
  onDelete: (itemId: string) => void
  compact?: boolean
}

const TYPE_LABELS: Record<string, string> = {
  reflection: '\U0001f4ad', achievement: '\U0001f3c6', project_update: '\U0001f4ca',
  link: '\U0001f517', habit_entry: '\u26a1',
}

export function MessageBubble({ item, categories, onReassign, onDelete, compact }: MessageBubbleProps) {
  const [open, setOpen] = useState(false)
  const topLevel = (categories ?? []).filter((c) => !c.parent_id)
  const formattedDate = new Intl.DateTimeFormat('en-GB', {
    month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit',
  }).format(new Date(item.created_at))

  return (
    <div className="flex flex-col items-end gap-1 group">
      <div className="flex items-start gap-1.5 justify-end w-full">
        <button onClick={() => onDelete(item.id)}
          className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 mt-1 text-muted-foreground hover:text-destructive shrink-0" title="Delete">
          <Trash2 className="w-3.5 h-3.5" />
        </button>
        <div className="max-w-[85%] rounded-2xl rounded-tr-sm bg-primary text-primary-foreground px-4 py-2.5 shadow-sm">
          <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">{item.content}</p>
        </div>
      </div>
      <div className="flex items-center gap-1.5 px-1 flex-wrap justify-end">
        <span className="text-xs text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity">{formattedDate}</span>
        {item.type && item.type !== 'task' && TYPE_LABELS[item.type] && (
          <Badge variant="outline" className="text-xs px-1.5 py-0">{TYPE_LABELS[item.type]}</Badge>
        )}
        {item.project && (
          <Badge variant="secondary" className="text-xs bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200">
            {item.project.emoji} {item.project.name}
          </Badge>
        )}
        {!compact && categories && onReassign && (
          <DropdownMenu open={open} onOpenChange={setOpen}>
            <DropdownMenuTrigger asChild>
              <button className="focus:outline-none">
                <Badge variant="secondary" className="text-xs cursor-pointer hover:bg-secondary/80 transition-colors">
                  {item.category?.emoji} {item.category?.name ?? 'Uncategorised'}
                </Badge>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <div className="px-2 py-1.5 text-xs font-medium text-muted-foreground">Move to\u2026</div>
              {topLevel.map((cat) => (
                <DropdownMenuItem key={cat.id} onClick={() => { onReassign(item.id, cat.id); setOpen(false) }}
                  className={item.category_id === cat.id ? 'bg-accent' : ''}>
                  {cat.emoji} {cat.name}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>
    </div>
  )
}
