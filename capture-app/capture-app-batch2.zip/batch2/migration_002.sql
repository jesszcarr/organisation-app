-- ============================================================
-- Migration 002: Aliases, completed_at, tag improvements
-- Paste into Supabase SQL Editor and run
-- ============================================================

-- 1. Project aliases for shorthand matching
alter table projects add column if not exists aliases text not null default '';

update projects set aliases = 'GF, graphs, graph foundation, seth, daniel, graphpfn' where name = 'graphfm';
update projects set aliases = 'DI, dev interp, developmental interpretability, grokking, fourier, leo, quentin, marek, lauren, jace' where name = 'Dev interp';
update projects set aliases = 'FQ, flair, quant, LOB, limit order book, SSM, GDN, jakob, kang' where name = 'FLAIR/quant';

-- 2. Completed_at timestamp on items (for todo lifecycle)
alter table items add column if not exists completed_at timestamptz;

create index if not exists items_completed_at on items(completed_at);

-- 3. Ensure tags tables exist and are usable
-- (These were created in migration 001 but let's make sure)
create table if not exists tags (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  name text not null,
  created_at timestamptz default now() not null,
  unique(user_id, name)
);

alter table tags enable row level security;
drop policy if exists "Users see own tags" on tags;
create policy "Users see own tags" on tags for all using (auth.uid() = user_id);

create table if not exists item_tags (
  item_id uuid references items(id) on delete cascade not null,
  tag_id uuid references tags(id) on delete cascade not null,
  primary key (item_id, tag_id)
);

alter table item_tags enable row level security;
drop policy if exists "Users see own item tags" on item_tags;
create policy "Users see own item tags" on item_tags for all
  using (item_id in (select id from items where user_id = auth.uid()));
